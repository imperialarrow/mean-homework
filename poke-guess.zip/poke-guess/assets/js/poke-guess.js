// jQuerry Listeners
$(function(){
	$('#user-guess').click(makeGuess);

	start();
});

function start(){
	var counter = 10;
	makeGray();
	makeHidden();
}

var poke_array = ['bulbasaur', 'ivysaur', 'venusaur', 'charmander', 'charmeleon', 'butterfree', 'pidgey', 'rattata', 'arbok', 'sandslash', 'nidorino', 'vulpix', 'ninetales', 'jigglypuff', 'golbat', 'oddish', 'diglett', 'persian', 'growlithe', 'poliwag'];

var timer = setInterval(countDown, 1000);
function makeGuess(){
	//alert('it works!');
	randImg();
}

function makeHidden(){
	$('.tepig').hide();
}

function makeGray(){
	$('.pokeball').attr('src', 'assets/img/pokeball-grey.png');
}

var Pokemon = function (name){
	this.name = name;
	this.path = 'assets/img/' + (poke_array.indexOf(name) + 1) + '.png';
}

function randImg(){
	var randomName = poke_array[Math.floor(Math.random() * poke_array.length)];
	alert(randomName + " helllllllooooooo");
	var newPokemon = new Pokemon(randomName);
	$('#pokemon').attr('src', newPokemon.path);
}

var countDown = function(){
	counter--;
	$('#timer').html(counter);
	if($('#timer') =0){
		clearInterval(timer);
	}
}